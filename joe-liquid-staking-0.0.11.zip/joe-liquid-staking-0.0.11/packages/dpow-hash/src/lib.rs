#[cfg(feature = "mining")]
pub mod miner;
pub mod proof;
