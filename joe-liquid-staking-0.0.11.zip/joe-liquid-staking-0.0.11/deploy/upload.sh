joed tx wasm store ./artifacts/pfc_steak_hub.wasm \
  --node https://joe-rpc.polkachu.com:443 \
  --chain-id joe-1 --from steak-admin \
  --gas-prices 1.1ujoe --gas 5000000 \
  --gas-adjustment 1.5 -y -b block