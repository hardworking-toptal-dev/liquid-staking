joed tx wasm migrate joe18yn206ypuxay79gjqv6msvd9t2y49w4fz8q7fyenx5aggj0ua37qnv0qf3 28 \
  --node https://joe-rpc.polkachu.com:443 \
  --chain-id joe-1 --from steak-admin \
  --gas-prices 1.1ujoe --gas 5000000 \
  --gas-adjustment 1.5 -y -b block